/*	SccsId:	%W%	%G%	*/

#ifndef _ATTRIBUTE_H_
#define _ATTRIBUTE_H_

typedef struct
{
	char	*name;
	char	format[20];
	int	order;
} Attribute;

#endif	/* _ATTRIBUTE_H_ */
