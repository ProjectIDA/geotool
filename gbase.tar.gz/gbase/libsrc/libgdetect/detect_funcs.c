#include "config.h"
/* detect_funcs.c
 * the original detect_funcs has been sharply reduced, as it contained GObj's
 */


double
squarex (double x)
     /*double  x;*/
{
        return (x * x);
}

double
samex (double x)
     /*double  x;*/
{
        return (x);
}
