/*
 * NAME
 *	stdtime_errno
 */

 /* *The* errno */
int	stdtime_errno = 0;
