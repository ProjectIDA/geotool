c	@(#)SCCSID: libstdtime_f77.h 82.1
c	@(#)SCCSID: Version Created: 08/27/98 12:26:27

	integer	stdtime_etoj
	integer	stdtime_htoj
	real*8	stdtime_htoe
	integer	stdtime_etoh
	integer	stdtime_jtoh

	

